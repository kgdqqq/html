// ==UserScript==
// @name         百度文库显示全文防止跳转
// @namespace    https://greasyfork.org/zh-CN
// @version      1.0
// @description  防止点击【显示全文】后自动跳转到充值页面
// @author       dorleone
// @include      https://wenku.baidu.com/view/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    window.onbeforeunload = function(){
       return false;
    }
})();