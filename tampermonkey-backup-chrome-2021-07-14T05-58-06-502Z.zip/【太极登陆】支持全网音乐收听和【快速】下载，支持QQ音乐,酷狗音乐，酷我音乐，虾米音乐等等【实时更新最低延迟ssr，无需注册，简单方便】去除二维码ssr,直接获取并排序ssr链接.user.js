// ==UserScript==
// @name         【太极登陆】支持全网音乐收听和【快速】下载，支持QQ音乐,酷狗音乐，酷我音乐，虾米音乐等等【实时更新最低延迟ssr，无需注册，简单方便】去除二维码ssr,直接获取并排序ssr链接
// @namespace    http://www.baidu.com/
// @version      1.41
// @description  自动获取可用SSR链接并排序，你只需要复制后从剪贴板导入SSR工具即可，省去人工一个个添加节点，手机也可使用Yandex浏览器安装此脚本!此脚本仅用于交流学习之用，切不可用于违法用途，因此产生的所有责任与开发者无关，请于下载后24小时内删除脚本，谢谢配合!
// @description-Zh 2019-11-13更新：修复bug，务必更新
// @note         如果急需，网站线路又暂时不可用，请加群，群免费提供优质稳定的快速订阅,群：518920379，如果脚本还不能满足你的需求，请加群反馈更新。
//@note-ZH      加群获取实时脚本更新信息与内测脚本：功能1：自动检测音乐的音质，支持无损下载；功能2：vip视频解析，支持选集，去网址广告，接口精挑细选快速缓冲，匹配对应接口；功能3：购机助手（买手机不懂选择？多重属性性能说明对比，一目了然！）
// @author       luoawai
// @match        https://www.attackmen.com/*
// @include      *://music.163.com/*song*
// @include      *://y.qq.com/*/song/*
// @include      *://*.kugou.com/song/*
// @include      *://*.kuwo.cn/*
// @include      *://*.xiami.com/*
// @include      *://music.taihe.com/song*
// @include      *://*.1ting.com/player*
// @include      *://music.migu.cn/v*
// @include      *://*.qingting.fm/*
// @include      *://*.ximalaya.com/*
// @require      http://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @run-at       document-end
// @grant        unsafeWindow
// @grant        GM_addStyle
// ==/UserScript==

(function() {
       var href=window.location.href;
     var kk=document.createElement('div');
      kk.className='box-taiji';
    document.body.appendChild(kk);
       var music_title=new Array()
		music_title[0]="163.com"
		music_title[1]= "y.qq.com"
		music_title[2]= "ximalaya.com"
		music_title[3]= "kuwo.cn"
		music_title[4]= "xiami.com"
		music_title[5]= "taihe.com"
		music_title[6]= "1ting.com"
		music_title[7]= "migu.cn"
		music_title[8]= "qingting.fm"
		music_title[9]= "lizhi.fm"
        music_title[10]="kugou.com"
		for(var i=0;i<music_title.length;i++){
			if(href.indexOf(music_title[i])!= -1){
				 $(".box-taiji").click(function () {
                window.open('https://chinese-elements.com/m.html?zxm=' + encodeURIComponent(href));
            });
			}
		}
    if(href.indexOf("attackmen")!=-1){
window.getSsrData = function (){
        layer.open({
            title:'节点信息',
            area:'800px',
            offset: 't',
            skin: 'layui-layer-molv',
            content: '<textarea class="layui-textarea" style="width:100%;height:600px;background-color: #eaeaea;" id="ssrStr" readonly></textarea><span style="color:#ff1f46;">全选复制后在任务栏SSR图标上点击右键选择剪贴板批量导入</span>'
        });
        layer.load(1, {time: 10*1000});
        GetData(1);
    }
    function isNull(obj){
    return obj === null;
}
    function sort2(a,b){
        return a-b;
    }
    window.GetData = function (inPage){
        layui.$.ajax({
            type:"GET",
            url:"https://www.attackmen.com/freessr?page="+inPage+"&limit=85",
            dataType: "json",
            async: true,
            success: function(data) {
                var kk,ll,oo,fpx;
                var pp=[];
                var lol=[];
              console.log(data.count);
                for(var j=0; j<data.data.length;j++){
                   pp[j]=data.data[j].oversea_ping;
                    lol[pp[j]]=["海外延迟："+data.data[j].oversea_ping,"\n国家："+data.data[j].country,"\n"+data.data[j].ssrlink,"\n更新时间："+data.data[j].udtime];
                }
              pp=pp.sort(sort2);
              console.log(lol);
                for(var k=0;k<data.data.length;k++){
                $("#ssrStr").append(lol[pp[k]]+"\n\n");
                }
                    layer.closeAll('loading');
            }
        });
    }

      window.getSsrData2 = function (){
        layer.open({
            title:'节点信息',
            area:'800px',
            offset: 't',
            btn: '一键复制',
            yes: function(index, layero){
                layui.$("#ssrStr").focus();
                $("#ssrStr").select();
                document.execCommand("Copy");
                layer.msg('复制成功！');
            },
            skin: 'layui-layer-molv',
            content: '<textarea class="layui-textarea" style="width:100%;height:600px;background-color: #eaeaea;" id="ssrStr" readonly></textarea><span style="color:#ff1f46;">全选复制后在任务栏SSR图标上点击右键选择剪贴板批量导入</span>'
        });
        layer.load(1, {time: 10*1000});
        GetData2(1);
    }

        window.GetData2 = function (inPage){
        layui.$.ajax({
            type:"GET",
            url:"https://www.attackmen.com/freessr?page=1&limit=85",
            dataType: "json",
            async: true,
            success: function(data) {
                var kk,ll,oo,fpx;
                var pp=[];
                var lol=[];
                for(var j=0; j<data.data.length;j++){
                   pp[j]=data.data[j].oversea_ping;
                    lol[pp[j]]=[data.data[j].ssrlink];
                }
              pp=pp.sort(sort2);
              console.log(lol);
                for(var k=0;k<data.data.length;k++){
                $("#ssrStr").append(lol[pp[k]]+"\n\n");
                }
              layer.closeAll('loading');
            }
        });
    }
    layui.$("#data").append('<button class="layui-btn" id="btn" type="button">查看所有节点详情</button>');
      layui.$("#data").append('<button class="layui-btn" id="btn2" type="button" onclick="window.getSsrData2()">复制所有节点</button>');
    window.getSsrData();
    }
      GMaddStyle(`
  .mask2 {width:200px;height:100px;position:fixed;left:0px;top:320px;background-color: white;color:black;background-color: rgba(218,112,214,0.6);z-index:999999;text-align:center;border-radius:30px;line-height:100px;font-size:20px;font-weight:bold;}
.box-taiji{width:0px;height:80px;position:fixed;left:-40px;top:320px;border-left:40px solid #DA70D6;border-right:40px solid #6A5ACD;border-radius:50%;z-index:999999999;animation:move 2s linear infinite;}
.box-taiji:before,.box-taiji:after{position:absolute;content:"";display:block;}
.box-taiji:before{width:40px;height:40px;top:0px;left:-20px;z-index:1;background-color:#DA70D6;border-radius:50%;box-shadow:0 39.5px 0 #6A5ACD;}
.box-taiji:after{width:20px;height:20px;top:10px;left:-10px;z-index:2;background-color:#6A5ACD;border-radius:50%;box-shadow:0 40px 0 #DA70D6;}
@keyframes move{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}
  `);
    $("#btn").on("click",function(){
    window.getSsrData();
    });
     $("#btn2").on("click",function(){
    window.getSsrData2();
    });
     function GMaddStyle(cssText){
    let a = document.createElement('style');
    a.textContent = cssText;
    let doc = document.head || document.documentElement;
    doc.appendChild(a);
  }
    $(".box-taiji").on('mouseover', function(){$(".box-taiji").attr("style","left:0px");});
    $(".box-taiji").on('mouseout', function(){$(".box-taiji").attr("style","left:-40px");});
})();
