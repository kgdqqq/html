// ==UserScript==
// @name        🔥🔥🔥超级工具🔥🔥🔥
// @description 1、自动跳过视频广告, 当前支持 腾讯, 爱奇艺, 优酷, 搜狐, 芒果TV, PPTV。2、图片下载：贴吧、图虫图片下载、微信公众号文章图片。3、自动展开页面的隐藏内容：目前支持豆瓣、站长之家、米坛、cnbeta、知乎、慕课网、Awesomes、喜马拉雅、CSDN博客、CSDN下载、道客88、百度文库、百度知道、回形针、人民日报客户端、凤凰网...大家如有发现类似需要手动点开隐藏内容的网站，请联系开发者。4、一键解析全网会员视频，热门视频推荐，淘宝、天猫、京东、拼多多优惠券领取，免费小说。5、跳转链接直达，去掉确定跳转链接页面，用于简书、知乎、CSDN。6、短视频解析功能：支持解析各大短视频平台的分享链接。7、二维码生成：支持生成当前网址的二维码。8、优惠券自动查询：已经支持淘宝天猫和京东购物优惠券
// @namespace   http://payback.bwaq.cn
// @icon        http://payback.bwaq.cn/logo.png
// @author      星星龙♪(･ω･)ﾉ
// @version     1.0.5
// @include     *
// @license     MIT License
// @require     https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js
// @require     https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.min.js
// @require     https://cdn.staticfile.org/mustache.js/3.1.0/mustache.min.js
// @require     https://cdn.bootcss.com/jquery/3.5.1/jquery.min.js
// @require     https://cdn.bootcss.com/toastr.js/2.1.3/toastr.min.js
// @require     https://cdn.bootcss.com/jszip/3.1.5/jszip.min.js
// @resource    Bootstrap http://libs.baidu.com/bootstrap/3.1.1/css/bootstrap.min.css
// @resource    toastr_css https://cdn.bootcss.com/toastr.js/2.1.3/toastr.min.css
// @resource    iconInfo http://payback.bwaq.cn/logo.png
// @connect     *
// @grant       unsafeWindow
// @grant       GM_openInTab
// @grant       GM.getValue
// @grant       GM.setValue
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_xmlhttpRequest
// @grant       GM.xmlHttpRequest
// @grant       GM_info
// @grant       GM_deleteValue
// @grant       GM_listValues
// @grant       GM_unregisterMenuCommand
// @grant       GM_registerMenuCommand
// @grant       GM_notification
// @grant       GM_setClipboard
// @grant       GM_download
// @grant       GM_addStyle
// @grant       GM_getResourceURL
// @grant       GM_getResourceText
// @antifeature referral-link 应GreasyFork代码规范要求：含有优惠券查询功能的脚本必须添加此提示！在此感谢大家的理解...
// ==/UserScript==
(function () {
    'use strict';

    var website$8 = {
      init: function init() {
        if (location.href.indexOf('www.iqiyi.com') === -1) {
          return;
        }

        setInterval(function () {
          var skip_guanggao = document.getElementsByClassName("skippable-after")[0];

          if (skip_guanggao) {
            skip_guanggao.click();
          }
        }, 1000);
      }
    };

    function _unsupportedIterableToArray(o, minLen) {
      if (!o) return;
      if (typeof o === "string") return _arrayLikeToArray(o, minLen);
      var n = Object.prototype.toString.call(o).slice(8, -1);
      if (n === "Object" && o.constructor) n = o.constructor.name;
      if (n === "Map" || n === "Set") return Array.from(o);
      if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
    }

    function _arrayLikeToArray(arr, len) {
      if (len == null || len > arr.length) len = arr.length;

      for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

      return arr2;
    }

    function _createForOfIteratorHelper(o, allowArrayLike) {
      var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];

      if (!it) {
        if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
          if (it) o = it;
          var i = 0;

          var F = function () {};

          return {
            s: F,
            n: function () {
              if (i >= o.length) return {
                done: true
              };
              return {
                done: false,
                value: o[i++]
              };
            },
            e: function (e) {
              throw e;
            },
            f: F
          };
        }

        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }

      var normalCompletion = true,
          didErr = false,
          err;
      return {
        s: function () {
          it = it.call(o);
        },
        n: function () {
          var step = it.next();
          normalCompletion = step.done;
          return step;
        },
        e: function (e) {
          didErr = true;
          err = e;
        },
        f: function () {
          try {
            if (!normalCompletion && it.return != null) it.return();
          } finally {
            if (didErr) throw err;
          }
        }
      };
    }

    var $$1 = $$1 || window.$;
    var common = {
      generic: function generic() {
        setInterval(function () {
          var $ad = $$1('body').find('video');

          if ($ad) {
            if ($ad.get()) {
              var videos = $ad.get(); // console.log(videos.length)

              var _iterator = _createForOfIteratorHelper(videos),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var video = _step.value;
                  var srcVal = $$1(video).attr('src'); // console.log(srcVal)

                  if (srcVal && !srcVal.startsWith('blob:')) {
                    video.currentTime = 1000;
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }
          }
        }, 1000);
      }
    };

    var website$7 = {
      init: function init() {
        if (location.href.indexOf('v.youku.com') === -1) {
          return;
        }

        common.generic();
      }
    };

    var website$6 = {
      init: function init() {
        if (location.href.indexOf('v.qq.com') === -1) {
          return;
        }

        common.generic();
      }
    };

    var website$5 = {
      init: function init() {
        if (location.href.indexOf('www.mgtv.com') === -1) {
          return;
        }

        common.generic();
      }
    };

    var website$4 = {
      init: function init() {
        if (location.href.indexOf('tv.sohu.com') === -1) {
          return;
        }

        common.generic();
      }
    };

    var website$3 = {
      init: function init() {
        if (location.href.indexOf('v.pptv.com') === -1) {
          return;
        }

        common.generic();
      }
    };

    var modules$6 = [website$8, website$7, website$6, website$5, website$4, website$3];
    var prepare$6 = {
      init: function init() {
        modules$6.forEach(function (module) {
          return module.init();
        });
      }
    };

    var tieba = {
      init: function init() {
        if (location.href.indexOf('tieba.baidu.com/p/') === -1) {
          return;
        }

        var commonUtils = function (document, $) {
          function parseURL(url) {
            var a = document.createElement('a');
            a.href = url;
            return {
              source: url,
              protocol: a.protocol.replace(':', ''),
              host: a.hostname,
              port: a.port,
              query: a.search,
              params: function () {
                var ret = {},
                    seg = a.search.replace(/^\?/, '').split('&'),
                    len = seg.length,
                    i = 0,
                    s;

                for (; i < len; i++) {
                  if (!seg[i]) {
                    continue;
                  }

                  s = seg[i].split('=');
                  ret[s[0]] = s[1];
                }

                return ret;
              }(),
              file: (a.pathname.match(/\/([^\/?#]+)$/i) || [, ''])[1],
              hash: a.hash.replace('#', ''),
              path: a.pathname.replace(/^([^\/])/, '/$1'),
              relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [, ''])[1],
              segments: a.pathname.replace(/^\//, '').split('/')
            };
          }

          function ajaxDownload(url, callback, args, tryTimes) {
            tryTimes = tryTimes || 0;
            var GM_download = GM.xmlHttpRequest || GM_xmlHttpRequest,
                clearUrl = url.replace(/[&\?]?download_timestamp=\d+/, ''),
                retryUrl = clearUrl + (clearUrl.indexOf('?') === -1 ? '?' : '&') + 'download_timestamp=' + new Date().getTime();
            GM_download({
              method: 'GET',
              responseType: 'blob',
              url: url,
              onreadystatechange: function onreadystatechange(responseDetails) {
                if (responseDetails.readyState === 4) {
                  if (responseDetails.status === 200 || responseDetails.status === 304 || responseDetails.status === 0) {
                    var blob = responseDetails.response,
                        size = blob && blob.size;

                    if (size && size / 1024 >= 5) {
                      callback(blob, args);
                    } else if (tryTimes++ == 3) {
                      callback(blob, args);
                    } else {
                      ajaxDownload(retryUrl, callback, args, tryTimes);
                    }
                  } else {
                    if (tryTimes++ == 3) {
                      callback(null, args);
                    } else {
                      ajaxDownload(retryUrl, callback, args, tryTimes);
                    }
                  }
                }
              },
              onerror: function onerror(responseDetails) {
                if (tryTimes++ == 3) {
                  callback(null, args);
                } else {
                  ajaxDownload(retryUrl, callback, args, tryTimes);
                } //console.log(responseDetails.status);

              }
            });
          }

          function fileNameFromHeader(disposition, url) {
            var result = null;

            if (disposition && /filename=.*/ig.test(disposition)) {
              result = disposition.match(/filename=.*/ig);
              return decodeURI(result[0].split("=")[1]);
            }

            return url.substring(url.lastIndexOf('/') + 1);
          }

          function downloadBlobFile(content, fileName) {
            if ('msSaveOrOpenBlob' in navigator) {
              navigator.msSaveOrOpenBlob(content, fileName);
            } else {
              var aLink = document.createElement('a');
              aLink.download = fileName;
              aLink.style = "display:none;";
              var blob = new Blob([content]);
              aLink.href = window.URL.createObjectURL(blob);
              document.body.appendChild(aLink);

              if (document.all) {
                aLink.click(); //IE
              } else {
                var evt = document.createEvent("MouseEvents");
                evt.initEvent("click", true, true);
                aLink.dispatchEvent(evt); // 其它浏览器
              }

              window.URL.revokeObjectURL(aLink.href);
              document.body.removeChild(aLink);
            }
          }

          function downloadUrlFile(url, fileName) {
            var aLink = document.createElement('a');

            if (fileName) {
              aLink.download = fileName;
            } else {
              aLink.download = url.substring(url.lastIndexOf('/') + 1);
            }

            aLink.target = "_blank";
            aLink.style = "display:none;";
            aLink.href = url;
            document.body.appendChild(aLink);

            if (document.all) {
              aLink.click(); //IE
            } else {
              var evt = document.createEvent("MouseEvents");
              evt.initEvent("click", true, true);
              aLink.dispatchEvent(evt); // 其它浏览器
            }

            document.body.removeChild(aLink);
          }

          function paddingZero(num, length) {
            return (Array(length).join("0") + num).substr(-length);
          }
          /*  Class: TaskQueue
           *  Constructor: handler
           *      takes a function which will be the task handler to be called,
           *      handler should return Deferred object(not Promise), if not it will run immediately;
           *  methods: append
           *      appends a task to the Queue. Queue will only call a task when the previous task has finished
           */


          var TaskQueue = function TaskQueue(handler) {
            var tasks = []; // empty resolved deferred object

            var deferred = $.when(); // handle the next object

            function handleNextTask() {
              // if the current deferred task has resolved and there are more tasks
              if (deferred.state() == "resolved" && tasks.length > 0) {
                // grab a task
                var task = tasks.shift(); // set the deferred to be deferred returned from the handler

                deferred = handler(task); // if its not a deferred object then set it to be an empty deferred object

                if (!(deferred && deferred.promise)) {
                  deferred = $.when();
                } // if we have tasks left then handle the next one when the current one
                // is done.


                if (tasks.length >= 0) {
                  deferred.fail(function () {
                    tasks = [];
                  });
                  deferred.done(handleNextTask);
                }
              }
            } // appends a task.


            this.append = function (task) {
              // add to the array
              tasks.push(task); // handle the next task

              handleNextTask();
            };
          };

          var context = {
            "ajaxDownload": ajaxDownload,
            "fileNameFromHeader": fileNameFromHeader,
            "downloadBlobFile": downloadBlobFile,
            "downloadUrlFile": downloadUrlFile,
            "parseURL": parseURL,
            "paddingZero": paddingZero,
            "TaskQueue": TaskQueue
          };
          return context;
        }(document, jQuery);

        var options = {
          "type": 2,
          "isNeedConfirmDownload": true,
          "useQueueDownloadThreshold": 0,
          "suffix": null,
          "callback": {
            "parseLocationInfo_callback": function parseLocationInfo_callback(location_info, options) {
              return commonUtils.parseURL(document.location.href);
            },
            "parseFiles_callback": function parseFiles_callback(location_info, options) {
              // file.url file.folder_sort_index
              // not folder_sort_index -> use fileName
              var files = [];
              return files;
            },
            "makeNames_callback": function makeNames_callback(arr, location_info, options) {
              var names = {};
              var time = new Date().getTime();
              names.zipName = "pack_" + time;
              names.folderName = names.zipName;
              names.infoName = null;
              names.infoValue = null;
              names.prefix = time;
              names.suffix = options.suffix;
              return names;
            },
            "beforeFilesDownload_callback": function beforeFilesDownload_callback(files, names, location_info, options, zip, main_folder) {},
            "beforeFileDownload_callback": function beforeFileDownload_callback(file, location_info, options, zipFileLength, zip, main_folder, folder) {},
            "eachFileOnload_callback": function eachFileOnload_callback(blob, file, location_info, options, zipFileLength, zip, main_folder, folder) {},
            "allFilesOnload_callback": function allFilesOnload_callback(files, names, location_info, options, zip, main_folder) {},
            "beforeZipFileDownload_callback": function beforeZipFileDownload_callback(zip_blob, files, names, location_info, options, zip, main_folder) {
              commonUtils.downloadBlobFile(zip_blob, names.zipName + ".zip");
            }
          }
        };

        var ajaxDownloadAndZipFiles = function ajaxDownloadAndZipFiles(files, names, location_info, options) {
          // GM_notification("开始下载～", names.zipName);
          var notify_start = toastr.success("正在打包～", names.zipName, {
            "progressBar": false,
            "hideDuration": 0,
            "showDuration": 0,
            "timeOut": 0,
            "closeButton": false
          });

          if (files && files.length > 0) {
            var zip = new JSZip();
            var main_folder = zip.folder(names.folderName);
            var zipFileLength = 0;
            var maxIndex = files.length;
            var paddingZeroLength = (files.length + "").length;

            if (names.infoName) {
              main_folder.file(names.infoName, names.infoValue);
            }

            options.callback.beforeFilesDownload_callback(files, names, location_info, options, zip, main_folder);

            var downloadFile = function downloadFile(file, resolveCallback) {
              return $.Deferred(function (dfd) {
                var folder = file.location ? main_folder.folder(file.location) : main_folder;
                var isSave = options.callback.beforeFileDownload_callback(file, location_info, options, zipFileLength, zip, main_folder, folder);

                if (isSave !== false) {
                  commonUtils.ajaxDownload(file.url, function (blob, file) {
                    var isSave = options.callback.eachFileOnload_callback(blob, file, location_info, options, zipFileLength, zip, main_folder, folder);

                    if (isSave !== false) {
                      if (file.fileName) {
                        folder.file(file.fileName, blob);
                      } else {
                        var suffix = names.suffix || file.url.substring(file.url.lastIndexOf('.') + 1);
                        file.fileName = names.prefix + "_" + commonUtils.paddingZero(file.folder_sort_index, paddingZeroLength) + "." + suffix;
                        folder.file(file.fileName, blob);
                      }
                    }

                    dfd.resolveWith(file, [blob, folder, isSave]);
                  }, file);
                } else {
                  dfd.resolveWith(file, [null, folder, false]);
                }
              }).done(function (blob, folder, isSave) {
                zipFileLength++;
                notify_start.find(".toast-message").text("正在打包～ 第 " + zipFileLength + " 张" + (isSave ? "" : "跳过"));
                resolveCallback && resolveCallback(); // resolve延迟对象

                if (zipFileLength >= maxIndex) {
                  var isDownloadZip = options.callback.allFilesOnload_callback(files, names, location_info, options, zip, main_folder);

                  if (isDownloadZip !== false) {
                    zip.generateAsync({
                      type: "blob"
                    }).then(function (content) {
                      options.callback.beforeZipFileDownload_callback(content, files, names, location_info, options, zip, main_folder);
                    }); // GM_notification({text: "打包下载完成！", title: names.zipName, highlight : true});

                    toastr.success("下载完成！", names.zipName, {
                      "progressBar": false,
                      timeOut: 0
                    });
                  }

                  notify_start.css("display", "none").remove();
                }
              });
            };

            if (maxIndex < options.useQueueDownloadThreshold) {
              // 并发数在useQueueDownloadThreshold内，直接下载
              for (var i = 0; i < maxIndex; i++) {
                downloadFile(files[i]);
              }
            } else {
              // 并发数在useQueueDownloadThreshold之上，采用队列下载
              var queue = new commonUtils.TaskQueue(function (file) {
                if (file) {
                  var dfd = $.Deferred();
                  downloadFile(file, function () {
                    dfd.resolve();
                  });
                  return dfd;
                }
              });

              for (var j = 0; j < maxIndex; j++) {
                queue.append(files[j]);
              }
            }
          } else {
            notify_start.css("display", "none").remove();
            toastr.error("未解析到图片！", "错误", {
              "progressBar": false
            });
          }
        };
        /** 批量下载 **/


        function batchDownload(config) {
          try {
            options = $.extend(true, {}, options, config);
            var location_info = options.callback.parseLocationInfo_callback(options);
            var files = options.callback.parseFiles_callback(location_info, options);

            if (!(files && files.promise)) {
              files = $.when(files);
            }

            files.done(function (files) {
              if (files && files.length > 0) {
                if (!options.isNeedConfirmDownload || confirm("是否下载 " + files.length + " 张图片")) {
                  var names = options.callback.makeNames_callback(files, location_info, options);
                  options.location_info = location_info;
                  options.files = files;
                  options.names = names;

                  if (options.type == 1) {
                    urlDownload(files, names, location_info, options);
                  } else {
                    ajaxDownloadAndZipFiles(files, names, location_info, options);
                  }
                }
              } else {
                toastr.error("未找到图片~", "");
              }
            }).fail(function (message) {
              toastr.error(message, "错误");
            });
          } catch (e) {
            // GM_notification("批量下载照片 出现错误！", "");
            console.warn("批量下载照片 出现错误！, exception: ", e);
            toastr.error("批量下载照片 出现错误！", "");
          }
        }
        /** 下载 **/


        function urlDownload(photos, names, location_info, options) {
          GM_notification("开始下载～", names.zipName);
          var index = 0;
          var interval = setInterval(function () {
            if (index < photos.length) {
              var url = photos[index].url;
              var fileName = null;

              if (!names.suffix) {
                fileName = names.prefix + "_" + (index + 1) + url.substring(url.lastIndexOf('.'));
              } else {
                fileName = names.prefix + "_" + (index + 1) + "." + names.suffix;
              }

              commonUtils.downloadUrlFile(url, fileName);
            } else {
              clearInterval(interval);
              return;
            }

            index++;
          }, 100);
        } //右键新标签打开图片直接打开原图


        function initRightClickOpenSource() {
          var url = document.location.toString();
          var m = null;

          if (!(m = url.match(/^https?:\/\/(imgsrc|tiebapic)\.baidu\.com\/forum\/pic\/item\/.+/i))) {
            if (m = url.match(/^(https?):\/\/(imgsrc|imgsa|tiebapic|\w+\.hiphotos)\.(?:bdimg|baidu)\.com\/(?:forum|album)\/.+\/(\w+\.(?:jpg|jpeg|gif|png|bmp|webp))(?:\?.+)?$/i)) {
              document.location = m[1] + "://" + (m[2] == "tiebapic" ? "tiebapic" : "imgsrc") + ".baidu.com/forum/pic/item/" + m[3];
            }
          }
        }
        /*** start main ***/
        //右键新标签打开图片直接打开原图


        initRightClickOpenSource();

        var getReplyAuthorUid = function getReplyAuthorUid($reply) {
          // 获取回复UID
          var userInfoStr = $reply.find('.d_name').attr('data-field');
          return userInfoStr && userInfoStr.match(/"user_id":(\d+)/) && RegExp.$1 || 0;
        };

        var getPostAuthorUid = function getPostAuthorUid() {
          // 获取楼主UID
          return getReplyAuthorUid($('#j_p_postlist').children('.j_l_post').first());
        }; // css


        GM_addStyle(GM_getResourceText('toastr_css')); // 添加按钮

        var $lis_nav = $('#tb_nav').find('ul').eq(0).find('li'),
            li_count = $lis_nav.length,
            $li_right = $lis_nav.eq(li_count - 1),
            html = '';

        if ($li_right.hasClass('none_right_border')) {
          var isStarTie = $li_right.hasClass('star_nav_tab');

          if (isStarTie) {
            html = '<li class="none_right_border star_nav_tab" style="cursor: pointer"><div class="star_nav_tab_inner"><div class="space">' + '<a title="点击下载本页图片" class="star_nav_ico star_nav_ico_photo" id="batchDownloadBtn"><i class="icon"></i>下载</a></div></div></div>';
          } else {
            html = '<li class="none_right_border j_tbnav_tab" style="cursor: pointer"><div class="tbnav_tab_inner"><p class="space">' + '<a title="点击下载本页图片" class="nav_icon icon_jingpin  j_tbnav_tab_a" id="batchDownloadBtn"  location="tabplay" >下载</a></p></div></div>';
          }

          $li_right.removeClass('none_right_border').after(html);
        } else {
          html = '<li class="j_tbnav_tab" style="cursor: pointer"><a class="j_tbnav_tab_a" id="batchDownloadBtn">下载</a> </li>';
          $li_right.after(html);
        } // 仪表盘控制栏添加按钮


        GM_registerMenuCommand('下载图片', function () {
          tiebaImagesDownload();
        });
        GM_registerMenuCommand('只下楼主', function () {
          tiebaImagesDownload({
            "onlyLz": true
          });
        });
        $('#batchDownloadBtn').click(function () {
          tiebaImagesDownload({
            "onlyLz": document.location.href.indexOf('see_lz=1') !== -1 && confirm("是否只下载楼主的图片")
          });
        });

        var tiebaImagesDownload = unsafeWindow.tiebaImagesDownload = function (options) {
          var config = {
            "type": 2,
            "minWidth": 100,
            "suffix": null,
            "packNameBy": "title",
            // "id" or "title"
            "baiduLoadPhotosApi": "https://tieba.baidu.com/photo/bw/picture/guide",
            "findPhotoByApi": true,
            "onlyLz": false,
            "callback": {
              "parseFiles_callback": function parseFiles_callback(location_info, options) {
                var pn = location_info.params.pn || 1,
                    authorUid = getPostAuthorUid(),
                    findPhotosByPage = function findPhotosByPage() {
                  var photo_arr = [],
                      $part_nodes_one = $('.d_post_content,.d_post_content_main').find("img"); //let part_nodes_two = $('.d_post_content_main,.post_bubble_middle,.d_post_content').find("img");

                  $.each($part_nodes_one, function (i, img) {
                    var $img = $(img);

                    if (options.onlyLz) {
                      // 只下楼主
                      var replyUid = getReplyAuthorUid($img.closest('.j_l_post'));

                      if (replyUid != authorUid) {
                        return;
                      }
                    } // 如果是广告图片则跳过


                    if (img.parentNode.tagName == "A" && img.parentNode.className.indexOf("j_click_stats") != -1) {
                      return true;
                    }

                    if (img.clientWidth >= options.minWidth) {
                      if ($img.hasClass("BDE_Image") || $img.hasClass("d_content_img")) {
                        var photo = {};
                        photo.location = "";
                        var thumb_url = img.src;
                        photo.folder_sort_index = photo_arr.length + 1; // 如果是用户上传的图片

                        if ($img.attr("pic_type") == "0") {
                          var urlMatcher = thumb_url.match(/^(https?):\/\/([a-zA-Z]+)\..*\/([^/]+)$/);
                          photo.url = urlMatcher[1] + "://" + (urlMatcher[2] == "tiebapic" ? "tiebapic" : "imgsrc") + ".baidu.com/forum/pic/item/" + urlMatcher[3];
                          photo.id = urlMatcher[3].match(/^[^.]+/)[0];
                        } // 如果是用户引用的图片
                        else {
                            var m = thumb_url.match(/^(https?):\/\/(imgsrc|imgsa|tiebapic|\w+\.hiphotos)\.(?:bdimg|baidu)\.com\/(?:forum|album)\/.+\/((\w+)\.(?:jpg|jpeg|gif|png|bmp|webp))(?:\?.+)?$/i); // 如果引用的是贴吧图片

                            if (m !== null) {
                              photo.url = m[1] + "://" + (m[2] == "tiebapic" ? "tiebapic" : "imgsrc") + ".baidu.com/forum/pic/item/" + m[3];
                              photo.id = m[4];
                            } else {
                              photo.url = thumb_url;
                            }
                          }

                        photo.size = $img.attr("size") || 0;
                        photo.location = "photos";
                        photo_arr.push(photo);
                      }
                    }
                  });
                  return photo_arr;
                };

                var notify_photo_data_loading = toastr.success("正在请求图片数据～", "", {
                  "progressBar": false,
                  "hideDuration": 0,
                  "showDuration": 0,
                  "timeOut": 0,
                  "closeButton": false
                });
                return $.Deferred(function (finalDfd) {
                  if (options.findPhotoByApi) {
                    var photo_arr = [],
                        curr_load_count = 0,
                        loadQueue = new commonUtils.TaskQueue(function (startPicId) {
                      return $.Deferred(function (dfd) {
                        $.get(options.baiduLoadPhotosApi, {
                          'tid': location_info.file,
                          'see_lz': options.onlyLz ? 1 : 0,
                          // 只下楼主
                          'from_page': 0,
                          // 'alt': 'jview',
                          'next': 50,
                          'prev': 0,
                          'pic_id': startPicId,
                          '_': new Date().getTime()
                        }, function (resp) {
                          var data = resp.data;

                          if (data && data.pic_list) {
                            var pic_amount = data.pic_amount,
                                pic_list = data.pic_list,
                                lastPicId,
                                startPushPic = false;
                            $.each(pic_list, function (key, pic) {
                              var original = pic.img.original,
                                  photo;

                              switch (true) {
                                case original.id == startPicId:
                                  startPushPic = true;
                                  break;

                                case !startPicId:
                                  startPushPic = true;

                                case startPushPic:
                                  photo = {};
                                  photo.location = "photos";
                                  photo.folder_sort_index = photo_arr.length + 1;
                                  photo.id = original.id;
                                  photo.url = original.waterurl && original.waterurl.replace(/^http:\/\//, 'https://') || "https://imgsrc.baidu.com/forum/pic/item/".concat(original.id, ".jpg");
                                  photo.size = original.size;
                                  photo_arr.push(photo);
                                  curr_load_count++;
                                  lastPicId = original.id;
                              }
                            });

                            if (lastPicId && curr_load_count < pic_amount) {
                              loadQueue.append(lastPicId);
                            } else {
                              // 队列下载结束
                              // 对比页面数据和api返回数据，两者合并结果，并尝试按页面显示顺序排序
                              var combine_photo_arr = [],
                                  page_photo_arr = findPhotosByPage().filter(function (photo) {
                                return photo.size != 0; // 有些页面图片没写size，所以这里过滤了没写size的，暂时先这样处理
                              }).map(function (photo) {
                                var has_delete = true;

                                if (photo.id) {
                                  var _iterator = _createForOfIteratorHelper(photo_arr),
                                      _step;

                                  try {
                                    for (_iterator.s(); !(_step = _iterator.n()).done;) {
                                      var p = _step.value;

                                      // 由于同样一张图片，id有两个，这里采用对比文件大小的方式来确定是否同一张图片
                                      if (p.id == photo.id || p.size != 0 && p.size == photo.size) {
                                        has_delete = false;
                                        break;
                                      }
                                    }
                                  } catch (err) {
                                    _iterator.e(err);
                                  } finally {
                                    _iterator.f();
                                  }
                                }

                                photo.has_delete = has_delete;
                                return photo;
                              }),
                                  pageLength = page_photo_arr.length,
                                  serverLength = photo_arr.length,
                                  hasDeleteLength = page_photo_arr.filter(function (photo) {
                                return photo.has_delete;
                              }).length;

                              if (hasDeleteLength > 0) {
                                var start_left_index = 0,
                                    start_right_index = 0,
                                    unshift_length = 0,
                                    i,
                                    j,
                                    photo_url_arr = photo_arr.map(function (photo) {
                                  return photo.url;
                                });
                                pn > 1 && $.each(page_photo_arr, function (i, photo) {
                                  var index = photo_url_arr.indexOf(photo.url);

                                  if (index != -1) {
                                    start_right_index = index;
                                    start_left_index = i;
                                    return false;
                                  } else {
                                    unshift_length++;
                                  }
                                });

                                if (start_right_index > 0) {
                                  combine_photo_arr.push.apply(combine_photo_arr, photo_arr.slice(0, start_right_index));
                                }

                                if (start_left_index > 0) {
                                  combine_photo_arr.push.apply(combine_photo_arr, page_photo_arr.slice(start_left_index - unshift_length, start_left_index));
                                }

                                for (i = start_left_index, j = start_right_index; i < pageLength && j < serverLength;) {
                                  var photo = void 0,
                                      left = page_photo_arr[i],
                                      right = photo_arr[j];

                                  if (left.id === right.id || left.size != 0 && left.size == right.size) {
                                    photo = right;
                                    i++;
                                    j++;
                                  } else {
                                    if (left.has_delete) {
                                      photo = left;
                                      i++;
                                    } else {
                                      photo = right;
                                      j++;
                                    }
                                  }

                                  combine_photo_arr.push(photo);
                                }

                                if (i <= pageLength - 1) {
                                  combine_photo_arr.push.apply(combine_photo_arr, page_photo_arr.slice(i, pageLength));
                                }

                                if (j <= serverLength - 1) {
                                  combine_photo_arr.push.apply(combine_photo_arr, photo_arr.slice(j, serverLength));
                                }

                                $.each(combine_photo_arr, function (i, photo) {
                                  photo.folder_sort_index = i + 1;
                                });
                              } else {
                                combine_photo_arr = photo_arr;
                              }

                              finalDfd.resolve(combine_photo_arr);
                            }

                            dfd.resolve();
                          } else {
                            dfd.reject('api返回错误');
                          }
                        }, 'json').fail(function () {
                          dfd.reject('api返回错误');
                        });
                      }).fail(function (msg) {
                        console.warn(msg);
                        options.findPhotoByApi = false;
                        finalDfd.resolve(findPhotosByPage());
                      });
                    });
                    loadQueue.append(null);
                  } else {
                    finalDfd.resolve(findPhotosByPage());
                  }
                }).always(function () {
                  notify_photo_data_loading.css("display", "none").remove();
                });
              },
              "makeNames_callback": function makeNames_callback(photos, location_info, options) {
                var names = {},
                    tie_id = location_info.file,
                    pn = location_info.params.pn || 1,
                    title = $(".core_title_txt").attr("title"),
                    forum = ($('#container').find('.card_title a.card_title_fname').text() || '贴').replace(/^\s*|\s*$/g, '');
                names.infoName = "tie_info.txt";
                names.infoValue = "id：" + tie_id + "\r\n" + "title：" + title + "\r\n" + "url：" + location_info.source + "\r\n" + "page：" + pn + "\r\n" + "image_amount：" + photos.length + "\r\n";
                names.zipName = (options.packNameBy == "id" ? "tie_" + tie_id : forum + '_' + tie_id + '_' + title) + (options.findPhotoByApi || pn == 1 ? "" : "_" + pn);
                names.folderName = names.zipName;
                names.prefix = tie_id + (options.findPhotoByApi ? "" : "_" + commonUtils.paddingZero(pn, 3));
                names.suffix = options.suffix;
                names.tie = {
                  'id': tie_id,
                  'title': title,
                  'pn': pn,
                  'forum': forum
                };
                return names;
              },
              "beforeFilesDownload_callback": function beforeFilesDownload_callback(photos, names, location_info, options, zip, main_folder) {
                var paddingZeroLength = (photos.length + "").length;
                $.each(photos, function (i, photo) {
                  photo.fileName = names.prefix + "_" + commonUtils.paddingZero(photo.folder_sort_index, paddingZeroLength) + "." + (names.suffix || photo.url.substring(photo.url.lastIndexOf('.') + 1));
                });
                options.failFiles = undefined;
              },
              "eachFileOnload_callback": function eachFileOnload_callback(blob, photo, location_info, options, zipFileLength, zip, main_folder, folder) {
                if (blob == null) {
                  if (!options.failFiles) {
                    options.failFiles = [];
                  }

                  options.failFiles.push(photo);
                } else if (!options.names.suffix && photo.location == 'photos' && blob.type && blob.type.indexOf('image/') === 0) {
                  // 如果没有指定后缀名，那么后缀根据content-type来判断
                  var suffixRegex = /\.[^.]+$/,
                      suffix = '.' + blob.type.replace('image/', '').replace('jpeg', 'jpg');
                  photo.fileName = photo.fileName.replace(suffixRegex, suffix);
                  photo.url = photo.url.replace(suffixRegex, suffix);
                }

                return true;
              },
              "allFilesOnload_callback": function allFilesOnload_callback(photos, names, location_info, options, zip, main_folder) {
                var photo_urls_str = "",
                    failPhotoListStr = ""; // 链接列表文件

                $.each(photos, function (i, photo) {
                  photo_urls_str += (photo.location ? photo.location + "/" : "") + photo.fileName + "\t" + photo.url + "\r\n";
                });
                main_folder.file("photo_url_list.txt", photo_urls_str); // 帮助文件

                main_folder.file("帮助.txt", "有些图片可能下载下来是裂掉的缩略图，可以从photo_url_list.text中按文件名手动找到链接下载。"); // 失败链接列表

                if (options.failFiles && options.failFiles.length > 0) {
                  toastr.error("共 " + options.failFiles.length + " 张下载失败，已记录在photos_fail_list.txt！", "", {
                    "progressBar": false,
                    timeOut: 0
                  });
                  failPhotoListStr = "";

                  for (var i in options.failFiles) {
                    var failFile = options.failFiles[i];
                    failPhotoListStr += failFile.location + "/" + failFile.fileName + "\t" + failFile.url + "\r\n";
                  }

                  main_folder.file("photos_fail_list.txt", failPhotoListStr);
                }
              }
            }
          };

          if (options) {
            $.extend(true, config, options);
          }

          batchDownload(config);
        };
      }
    };

    var tuchong = {
      init: function init() {
        if (location.href.indexOf('tuchong.com') === -1) {
          return;
        }

        $(document).ready(function () {
          if (location.href.indexOf('stock.tuchong.com/topic') !== -1) {
            createDownloadAllButtonTopic();
          } else if (location.href.indexOf('tuchong.com') !== -1) {
            createDownloadButton();
            createDownloadAllButton();
          }
        }); // 获取套图地址
        // 下载套图按钮

        function createDownloadAllButtonTopic() {
          var imagesContainer = $('.justified-layout');

          if (imagesContainer.length > 0) {
            /*以下是添加HTML节点 和 下载事件 设置*/
            var downloadAllIcon = '<svg class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" width="60" height="60"><path d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z" fill="#E52425" p-id="3019"></path><path d="M802.085 528.066c-19.343-24.572-43.631-40.047-73.004-46.567 4.013-11.965 6.018-24.286 6.018-36.968 0-28.154-9.313-52.083-27.94-71.784-18.627-19.63-41.266-29.517-67.845-29.517-19.272 0-36.896 5.66-52.872 16.907-13.971-25.289-33.24-45.707-57.885-61.182-24.575-15.475-51.368-23.212-80.313-23.212-28.943 0-55.665 7.594-80.31 22.71-24.646 15.188-44.06 35.75-58.388 61.756-14.257 26.078-21.422 54.234-21.422 84.466v8.455c-27.94 10.531-50.865 28.871-68.848 54.877-17.982 26.005-26.938 55.522-26.938 88.62 0 3.319 0.1 6.606 0.291 9.864 17.584-3.49 36.155-5.363 55.358-5.363 110.778 0 200.582 62.212 200.582 138.954 0 2.854-0.139 5.687-0.384 8.499H703.29c23.283 0 44.705-5.947 64.335-17.911 19.63-11.966 35.104-28.299 46.422-49.075 11.32-20.704 16.98-43.415 16.98-68.059 0-32.31-9.673-60.824-28.942-85.47zM596.4 574.489L490.656 686.396c-2.65 2.792-6.305 4.226-10.96 4.226-4.657 0-8.312-1.434-10.962-4.226L362.991 574.489c-4.657-4.871-5.66-10.889-3.009-17.909 2.651-7.021 7.665-10.53 14.972-10.53h64.837V427.84c0-4.873 1.503-8.955 4.513-12.107 3.008-3.152 6.805-4.729 11.462-4.729h47.928c4.658 0 8.454 1.576 11.462 4.729 3.01 3.152 4.516 7.163 4.516 12.107v118.21h64.834c7.308 0 12.323 3.51 14.975 10.53s1.648 13.038-3.081 17.909z" fill="#FFFFFF" p-id="3020"></path><path d="M247.988 601.128c-19.203 0-37.774 1.873-55.358 5.363 1.385 23.679 7.797 45.744 19.196 66.148 12.967 23.212 30.448 41.623 52.371 55.38 21.994 13.684 45.922 20.562 71.857 20.562h112.132c0.245-2.813 0.384-5.645 0.384-8.499 0-76.742-89.803-138.954-200.582-138.954z" fill="#FFFFFF" opacity=".4" p-id="3021"></path></svg>';
            var downloadAllContainer = '<div id="diy-download-all" class="toolbar-icon">' + downloadAllIcon + '</div>';
            var imgHrefs = imagesContainer.find('.justified-layout__item');
            $('.toolbar-wrapper').append(downloadAllContainer);
            $('#diy-download-all').on('click', function () {
              var imagePaires = [];

              for (var i = 0; i < imgHrefs.length; i++) {
                var imgUrl = $(imgHrefs[i]).find('div').attr('data-lazy-url'); //let imageName = imgUrl.split('/smh/')[1]

                if (!/http/.test(imgUrl)) {
                  imgUrl = 'http:' + imgUrl;
                }

                imagePaires.push(imgUrl);
              }

              console.log(imagePaires, 'imagePaires');
              packageImages(imagePaires);
            });
          }
        }

        function packageImages(imgUrls) {
          GM_notification({
            text: '正在打包中，稍后会下载，请勿重复点击！',
            image: GM_getResourceURL("iconInfo"),
            timeout: 3000
          });
          var imgBase64 = [];
          var imageSuffix = []; //图片后缀

          var zip = new JSZip();
          var img = zip.folder('images');

          for (var i = 0; i < imgUrls.length; i++) {
            var src = imgUrls[i];
            var suffix = src.substring(src.lastIndexOf('.'));
            imageSuffix.push(suffix);
            getBase64(src).then(function (base64) {
              imgBase64.push(base64.substring(22));
            }, function (err) {
              console.log(err); //打印异常信息
            });
          }

          function zipImage() {
            setTimeout(function () {
              if (imgUrls.length == imgBase64.length) {
                for (var _i = 0; _i < imgUrls.length; _i++) {
                  img.file('图片' + _i + imageSuffix[_i], imgBase64[_i], {
                    base64: true
                  });
                }

                zip.generateAsync({
                  type: 'blob'
                }).then(function (content) {
                  // see FileSaver.js
                  saveAs(content, 'images.zip');
                });
              } else {
                zipImage();
              }
            }, 100);
          }

          zipImage();
        } //传入图片路径，返回base64


        function getBase64(img) {
          function getBase64Image(img, width, height) {
            //width、height调用时传入具体像素值，控制大小 ,不传则默认图像大小
            var canvas = document.createElement('canvas');
            canvas.width = width ? width : img.width;
            canvas.height = height ? height : img.height;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            return canvas.toDataURL();
          }

          var image = new Image();
          image.crossOrigin = 'Anonymous';
          image.src = img;
          var deferred = $.Deferred();

          if (img) {
            image.onload = function () {
              deferred.resolve(getBase64Image(image)); //将base64传给done上传处理
            };

            return deferred.promise(); //问题要让onload完成后再return sessionStorage['imgTest']
          }
        }
        /*以下是添加HTML节点 和 下载事件 设置*/


        var downloadStyle = 'color:#fff;' + 'background-color:#5CB85C;' + 'cursor:pointer;' + 'display:inline-block;' + 'font-weight:400;' + 'text-align:center;' + 'vertical-align:middle;' + 'cursor:pointer;' + 'padding:6px 12px;' + 'margin:0 24px;' + 'border-radius: 4px;' + 'box-sizing: border-box;' + 'font-size:14px;'; // 获取单页地址
        // 下载单页按钮

        function createDownloadButton() {
          var imagesContainer = $('.scene-container-next');

          if (imagesContainer.length > 0) {
            var nodeElement = '<span id="diy-download" style="' + downloadStyle + '">图片下载</span>';
            $('.theater-handler').append(nodeElement);
            $('#diy-download').on('click', function () {
              var imgUrl = imagesContainer.find('.scene-item').not('.prev-scene').not('.next-scene').find('img').attr('src');
              var imgName = $('.aside-post-title').text() + imgUrl.split('/f/')[1];
              var re = /http/;

              if (!re.test(imgUrl)) {
                imgUrl = 'http:' + imgUrl;
              }

              console.log('下载单页按钮-点击:imgUrl>>>' + imgUrl + '\t\timgName>>>' + imgName);
              GM_download(imgUrl, imgName);
            });
          }
        } // 获取套图地址
        // 下载套图按钮


        function createDownloadAllButton() {
          var imagesContainer = $('.scene-container-next');

          if (imagesContainer.length > 0) {
            var nodeElement = '<span id="diy-download-all" style="' + downloadStyle + '">套图下载</span>';
            $('.theater-handler').append(nodeElement);
            $('#diy-download-all').on('click', function () {
              var imgItem = imagesContainer.find('.scene-item');
              var imagePaires = [];

              for (var i = 0; i < imgItem.length; i++) {
                var imgUrl = $(imgItem[i]).find('img').attr('src');
                var re = /http/;

                if (!re.test(imgUrl)) {
                  imgUrl = 'http:' + imgUrl;
                } //let imageName = $('.aside-post-title').text() + imgUrl.split('/f/')[1]


                imagePaires.push(imgUrl);
              }

              console.log('下载套图按钮-点击:imagePaires>>>>>' + imagePaires);
              packageImages(imagePaires);
            });
          }
        }
      }
    };

    var wechat = {
      init: function init() {
        if (location.href.indexOf('mp.weixin.qq.com/s') === -1) {
          return;
        }

        var bootstrap = GM_getResourceText('Bootstrap');
        GM_addStyle(bootstrap);
        var $downloadButton = $('<button class="btn btn-success" id="downloadButton" style="line-height: 32px"><span>一键下载所有图片</span> ' + '<span id=photoNum></span></button><a class="linkUrl" style="display:none;" download=""></a>');
        $downloadButton.on('click', function () {
          download(0);
        });
        $('#img-content').prepend($downloadButton);
        var imageUrl = $('#js_content')[0].getElementsByTagName('img');
        var images = Array();
        var imageTags = Array();

        for (var i = 0; i < imageUrl.length; i++) {
          if (imageUrl[i].dataset.src) {
            images.push(imageUrl[i].dataset.src);
          } else if (imageUrl[i].src) {
            var imageUrlFormat = imageUrl[i].src.replace('//res.wx.qq.com/mmbizwap', 'http://res.wx.qq.com/mmbizwap');
            images.push(imageUrlFormat);
          }

          imageTags.push(1);
        }

        dataSet.images = images;
        dataSet.imageTags = imageTags;
        $('#photoNum')[0].innerText = '共' + dataSet.images.length + '张';
      }
    };
    var dataSet = {
      'title': '',
      'images': Array(),
      'imageTags': Array()
    };

    function download(index) {
      var ext = '.jpg';

      if (dataSet.images[index].indexOf('wx_fmt=gif') > 0 || dataSet.images[index].indexOf('mmbiz_gif') > 0) {
        ext = '.gif';
      }

      if (dataSet.images[index].indexOf('wx_fmt=png') > 0 || dataSet.images[index].indexOf('mmbiz_png') > 0) {
        ext = '.png';
      }

      if (dataSet.images[index].indexOf('wx_fmt=bmp') > 0 || dataSet.images[index].indexOf('mmbiz_bmp') > 0) {
        ext = '.bmp';
      }

      var fileName = new Date().getTime() + '_' + index.toString() + ext;
      var downloader = GM.xmlHttpRequest || GM_xmlHttpRequest;
      downloader({
        method: 'GET',
        url: dataSet.images[index],
        responseType: 'blob',
        onload: function onload(xhr) {
          var blobURL = window.URL.createObjectURL(xhr.response);

          if (dataSet.imageTags[index] === 1) {
            var element = document.querySelector('.linkUrl');
            element.href = blobURL;
            element.setAttribute('download', fileName);
            element.click();
            window.URL.revokeObjectURL(blobURL);
            dataSet.imageTags[index] = 0;

            if (index < dataSet.images.length - 1) {
              index = index + 1;
              download(index);
            }
          }
        }
      });
    }

    var modules$5 = [tieba, tuchong, wechat];
    var prepare$5 = {
      init: function init() {
        modules$5.forEach(function (module) {
          return module.init();
        });
      }
    };

    var expansion = {
      init: function init() {
        var timer;
        var delayTime = 600;
        var buttons = ['.QuestionRichText-more', '.shadow-2n5oidXt', '.read_more_btn', '.paperclip__showbtn', '.expend', '.QuestionMainAction', '.ContentItem-expandButton', '.btn-readmore', '.show-hide-btn', '.down-arrow', '.js_show_topic', '.tbl-read-more-btn', '.more-intro-wrapper', '.showMore', '.unfoldFullText', '.taboola-open'];
        var asyncButtons = ['.wgt-best-showbtn', '.wgt-answers-showbtn', '#continueButton', '.bbCodeBlock-expandLink', '.read-more-zhankai'];
        window.addEventListener('load', function () {
          clearTimeout(timer);
          setTimeout(function () {
            return expandPage(asyncButtons, doAsyncShow, true);
          }, delayTime);
        });
        expandPage(buttons, doExpandPage, false);

        function expandPage(buttons, doExpandPage, hasDone) {
          for (var i = 0; i < buttons.length; i++) {
            var button = buttons[i];
            var element = document.querySelectorAll(button);

            if (!!element[0]) {
              doExpandPage(element, button);
            }
          }

          clearTimeout(timer);
          if (!hasDone) timer = setTimeout(function () {
            return expandPage(buttons, doExpandPage, false);
          }, delayTime);
        }

        function doExpandPage(elements, selectButton) {
          switch (selectButton) {
            case '.showMore':
              elements[0].querySelector('span').click();
              break;

            case '.paperclip__showbtn':
              elements.forEach(function (element) {
                return element.click();
              });
              break;

            default:
              elements[0].click();
              break;
          }
        }

        function doAsyncShow(element, hasDone) {
          element[0].click();
        }
      }
    };

    var modules$4 = [expansion];
    var prepare$4 = {
      init: function init() {
        modules$4.forEach(function (module) {
          return module.init();
        });
      }
    };

    // 电影搜索,音乐下载,购物券,电影解析,短视频解析
    var navigator$1 = {
      init: function init() {
        if (location.href.indexOf('360kan.com') === -1 && location.href.indexOf('iqiyi.com') === -1 && location.href.indexOf('v.qq.com') === -1 && location.href.indexOf('youku.com') === -1 && location.href.indexOf('mgtv.com') === -1 && location.href.indexOf('tv.sohu.com') === -1 && location.href.indexOf('le.com') === -1 && location.href.indexOf('pptv.com') === -1 && location.href.indexOf('www.wasu.cn') === -1 && location.href.indexOf('qidian.com') === -1 && location.href.indexOf('douyin.com') === -1 && location.href.indexOf('iesdouyin.com') === -1 && location.href.indexOf('huoshan.com') === -1 && location.href.indexOf('kuaishou.com') === -1 && location.href.indexOf('gifshow.com') === -1 && location.href.indexOf('chenzhongtech.com') === -1 && location.href.indexOf('pipix.com') === -1 && location.href.indexOf('weishi.qq.com') === -1 && location.href.indexOf('izuiyou.com') === -1 && location.href.indexOf('m.hanyuhl.com') === -1 && location.href.indexOf('m.acfun.cn/v/') === -1) {
          return;
        }

        if (/\\*.bwaq.cn/i.test(top.window.location.href)) {
          return;
        }

        var $ = window.$;

        if ($('#Wandhi-nav').length > 0) {
          return;
        }

        var menus;

        if (location.href.indexOf('qidian.com') > 0) {
          menus = [{
            title: '电影搜索',
            show: '电影<br>搜索',
            type: 'video'
          }, {
            title: '免费小说',
            show: '免费<br>小说',
            type: 'novel'
          }, {
            title: '淘宝好券',
            show: '淘宝<br>好券',
            type: 'tb'
          }, {
            title: '京东好券',
            show: '京东<br>好券',
            type: 'jd'
          }];
        } else if (location.href.indexOf('douyin.com') !== -1 || location.href.indexOf('iesdouyin.com') !== -1 || location.href.indexOf('huoshan.com') !== -1 || location.href.indexOf('kuaishou.com') !== -1 || location.href.indexOf('gifshow.com') !== -1 || location.href.indexOf('chenzhongtech.com') !== -1 || location.href.indexOf('pipix.com') !== -1 || location.href.indexOf('weishi.qq.com') !== -1 || location.href.indexOf('izuiyou.com') !== -1 || location.href.indexOf('m.hanyuhl.com') !== -1 || location.href.indexOf('m.acfun.cn/v/') !== -1) {
          menus = [{
            title: '电影搜索',
            show: '电影<br>搜索',
            type: 'video'
          }, {
            title: '视频解析',
            show: '视频<br>解析',
            type: 'parse'
          }, {
            title: '淘宝好券',
            show: '淘宝<br>好券',
            type: 'tb'
          }, {
            title: '京东好券',
            show: '京东<br>好券',
            type: 'jd'
          }];
        } else {
          menus = [{
            title: '电影搜索',
            show: '电影<br>搜索',
            type: 'video'
          }, {
            title: '视频解析',
            show: '视频<br>解析',
            type: 'movie'
          }, {
            title: '淘宝好券',
            show: '淘宝<br>好券',
            type: 'tb'
          }, {
            title: '京东好券',
            show: '京东<br>好券',
            type: 'jd'
          }];
        }

        initMenu(menus, function () {
          $('body').on('click', '[data-cat=movie]', function () {
            //视频解析
            window.open('http://movie.bwaq.cn?url=' + encodeURIComponent(window.location.href));
          });
          $('body').on('click', '[data-cat=video]', function () {
            //电影搜索
            window.open('http://video.bwaq.cn');
          });
          $('body').on('click', '[data-cat=tb]', function () {
            window.open('http://payback.bwaq.cn/');
          });
          $('body').on('click', '[data-cat=jd]', function () {
            window.open('http://jd.bwaq.cn');
          });
          $('body').on('click', '[data-cat=novel]', function () {
            window.open('http://payback.bwaq.cn/download/novel');
          });
          $('body').on('click', '[data-cat=parse]', function () {
            window.open('http://tools.bwaq.cn/#/video/parse?url=' + encodeURIComponent(window.location.href));
          });
        });
      }
    };

    function initMenu(obj, event) {
      var menusClass = ['first', 'second', 'third', 'fourth', 'fifth'];
      var menu = '';
      $.each(obj, function (i, item) {
        menu = menu + '<a href="javascript:void(0)" title="' + item.title + '" data-cat="' + item.type + '" class="menu-item menu-line menu-' + menusClass[i] + '">' + item.show + '</a>';
      });
      var sideNavigator = '<div class="aside-nav bounceInUp animated" id="Wandhi-nav"><label for="" class="aside-menu" title="按住拖动">VIP</label>' + menu + '</div>';
      $('body').append($('<link rel="stylesheet" href="//cdn.wandhi.com/style/tv/asidenav.css">')).append(sideNavigator);
      var drags = {
        down: false,
        x: 0,
        y: 0,
        winWidth: 0,
        winHeight: 0,
        clientX: 0,
        clientY: 0
      };
      var mainMenu = $('#Wandhi-nav')[0];
      $('body').on('mousedown', '#Wandhi-nav', function (a) {
        drags.down = true;
        drags.clientX = a.clientX;
        drags.clientY = a.clientY;
        drags.x = getCss(this, 'left');
        drags.y = getCss(this, 'top');
        drags.winHeight = $(window).height();
        drags.winWidth = $(window).width();
        $(document).on('mousemove', function (a) {
          var xMove = a.clientX - drags.clientX;
          var yMove = a.clientY - drags.clientY;
          mainMenu.style.top = parseInt(drags.y) + yMove + 'px';
          mainMenu.style.left = parseInt(drags.x) + xMove + 'px';
        });
      }).on('mouseup', '#Wandhi-nav', function () {
        drags.down = false;
        $(document).off('mousemove');
      });
      event();
    }

    var getCss = function getCss(a, e) {
      return document.defaultView.getComputedStyle(a, null)[e];
    };

    var modules$3 = [navigator$1];
    var prepare$3 = {
      init: function init() {
        modules$3.forEach(function (module) {
          return module.init();
        });
      }
    };

    var website$2 = {
      init: function init() {
        if (location.href.indexOf('jianshu.com/go-wild?ac=2&url=') === -1) {
          return;
        }

        var regex = location.href.match(/url=(.+?)(&|$)/);

        if (regex && regex.length == 3) {
          var url = decodeURIComponent(regex[1]); //console.log(url)

          location.href = url;
        }
      }
    };

    var website$1 = {
      init: function init() {
        if (location.href.indexOf('link.csdn.net/?target=') === -1) {
          return;
        }

        var regex = location.href.match(/target=(.+?)(&|$)/);

        if (regex && regex.length == 3) {
          var url = decodeURIComponent(regex[1]); //console.log(url)

          location.href = url;
        }
      }
    };

    var website = {
      init: function init() {
        if (location.href.indexOf('link.zhihu.com/?target=') === -1) {
          return;
        }

        var regex = location.href.match(/target=(.+?)(&|$)/);

        if (regex && regex.length == 3) {
          var url = decodeURIComponent(regex[1]); //console.log(url)

          location.href = url;
        }
      }
    };

    var modules$2 = [website$2, website$1, website];
    var prepare$2 = {
      init: function init() {
        modules$2.forEach(function (module) {
          return module.init();
        });
      }
    };

    var qrcode = {
      init: function init() {
        var qrCodeUrl = 'https://api.pwmqr.com/qrcode/create/?url=';

        function createQrCode() {
          var qrCodeStyle = 'display:block;position:fixed;width:24px;height:24px;bottom:256px;right:1vmin;transition:0.5s all;background-color:#fff;background-image:url(https://s.aigei.com/src/img/png/23/23adca139a5c43c3809ab161f7f0453d.png?imageMogr2/auto-orient/thumbnail/!237x237r/gravity/Center/crop/237x237/quality/85/&e=1735488000&token=P7S2Xpzfz11vAkASLTkfHN7Fw-oOZBecqeJaxypL:z0u2BGZ4KZ3Lx5wegbSaidmXLTQ=);background-position:center;background-repeat:no-repeat;background-size:100%;box-shadow:0 0 0 2px red !important;cursor:pointer;z-index:9999999;border-radius:2px;';
          var qrCodeImgStyle = 'width:150px;height:150px;border-radius:6px;';
          var qrCode = document.createElement('div');
          qrCode.id = 'qrCodeUrl';
          qrCode.style = qrCodeStyle;
          document.body.appendChild(qrCode);
          $('#qrCodeUrl').hover(function () {
            this.style = qrCodeStyle + qrCodeImgStyle + 'background-image:url(' + qrCodeUrl + encodeURIComponent(location.href) + ');';
          }, function () {
            this.style = qrCodeStyle;
          });
        }

        if (location.href.match('^http(s)?://')) {
          createQrCode();
        }
      }
    };

    var modules$1 = [qrcode];
    var prepare$1 = {
      init: function init() {
        modules$1.forEach(function (module) {
          return module.init();
        });
      }
    };

    // 查询当前是否有优惠券
    var coupon = {
      init: function init() {
        if (location.href.indexOf('item.taobao.com') === -1 && location.href.indexOf('detail.liangxinyao.com') === -1 && location.href.indexOf('detail.tmall.com') === -1 && location.href.indexOf('item.jd.com') === -1) {
          return;
        }

        if (/\\*.bwaq.cn/i.test(top.window.location.href)) {
          return;
        }

        var $ = window.$;

        if ($('#Wandhi-nav').length > 0) {
          return;
        }

        var groupLink = 'https://qm.qq.com/cgi-bin/qm/qr?k=Rt6wP6M_S9xVOgdUtqNypuT2xPixHeIR&jump_from=webapi';
        var qrCodeApi = 'https://api.pwmqr.com/qrcode/create/?url=';
        var qrCodeStyle = 'width:100px;' + 'height:100px;' + 'background-color:#fff;' + 'background-position:center;' + 'background-repeat:no-repeat;' + 'background-size:100%;' + 'box-shadow:0 0 0 2px red !important;' + 'cursor:pointer;' + 'border-radius:10px;';
        $('head').append($('<link rel="stylesheet" href="//cdn.wandhi.com/style/extenstion/hui.style.css">'));
        var tableHtml = '<div id=\'wandhi_div\'><table class=\'wandhi_tab\' id=\'wandhi_table\'><thead><tr><th>' + '<b style=\'cursor:pointer\'>优惠券</b></th><th>券后</th><th>操作</th><th>扫码入群</th></tr></thead><tr><td colspan=\'4\'>正在查询优惠信息,请稍候...</td></tr></table></div>';

        if (location.href.indexOf('item.taobao.com') !== -1) {
          $('.J_LinkAdd').parent().parent().prepend(tableHtml);
          $('#wandhi_table').addClass('wandhi_tab_taobao');
          getCouponAli();
        } else if (location.href.indexOf('detail.tmall.com') !== -1 || location.href.indexOf('detail.liangxinyao.com') !== -1) {
          $('#J_LinkBasket').parent().parent().prepend(tableHtml);
          $('#wandhi_table').addClass('wandhi_tab_tmall');
          setTimeout(function () {
            $('#J_ButtonWaitWrap').hide();
            $('#J_LinkBuy').parent().removeClass('tb-hidden');
            $('#J_LinkBasket').parent().removeClass('tb-hidden');
            getCouponAli();
          }, 2000);
        } else if (location.href.indexOf('item.jd.com') !== -1) {
          $('#choose-attrs').append(tableHtml);
          $('#wandhi_table').addClass('wandhi_tab_tmall');
          getCouponJd();
        }

        function getCouponAli() {
          var bid = getQueryString('id');
          var requestUrl = 'https://v2.api.haodanku.com/ratesurl';
          $.post(requestUrl, {
            itemid: bid,
            apikey: 'tukergo',
            tb_name: 'a1265137718',
            pid: 'mm_112850864_1213550067_109914800094'
          }, function (res) {
            if (typeof res === 'string') {
              res = JSON.parse(res);
            }

            $('#wandhi_table tbody tr').remove();
            var row;

            if (res.code === 1) {
              if (res.data.couponmoney === '0') {
                row = '<tr>' + '<td>该商品无优惠券</td>' + '<td><a target="_blank" href=' + groupLink + '>更多好券低价好物</a></td>' + '<td colspan=\'2\'><img style=' + qrCodeStyle + '; src=' + qrCodeApi + encodeURIComponent(groupLink) + '/></td>' + '</tr>';
              } else {
                row = '<tr>' + '<td>' + (res.data.couponmoney + '元') + '</td>' + '<td><a target="_blank" href=' + res.data.coupon_click_url + '>立即领券</a></td>' + '<td><a target="_blank"  href=' + groupLink + '>更多好券低价好物</a></td>' + '<td><img style=' + qrCodeStyle + '; src=' + qrCodeApi + encodeURIComponent(groupLink) + '/></td>' + '</tr>';
              }
            } else {
              row = '<tr>' + '<td>该商品无优惠券</td>' + '<td><a target="_blank" href=' + groupLink + '>更多好券低价好物</a></td>' + '<td colspan=\'2\'><img style=' + qrCodeStyle + '; src=' + qrCodeApi + encodeURIComponent(groupLink) + '/></td>' + '</tr>';
            }

            $('#wandhi_table tbody').append(row);
          });
        }

        function getCouponJd() {
          var bid = location.href.match('\\d+(?=\\.html)');
          var requestUrl = 'https://server.bwaq.cn/tbk/api/goods/rates?channel=jd&goodsId=' + bid;
          $.getJSON(requestUrl, function (res) {
            if (typeof res === 'string') {
              res = JSON.parse(res);
            }

            $('#wandhi_table tbody tr').remove();
            var row;

            if (res.code === 10) {
              var item = res.data.jd;
              row = '<tr>' + '<td><a target="_blank" href=' + item.data + '>立即领券</a></td>' + '<td><a target="_blank" href=' + groupLink + '>更多好券低价好物</a></td>' + '<td colspan=\'2\'><img style=' + qrCodeStyle + '; src=' + qrCodeApi + encodeURIComponent(groupLink) + '/></td>' + '</tr>';
            } else {
              row = '<tr>' + '<td><a target="_blank" href=' + 'http://payback.bwaq.cn/goods?channel=jd&id=' + bid + '>立即领券</a></td>' + '<td><a target="_blank" href=' + groupLink + '>更多好券低价好物</a></td>' + '<td colspan=\'2\'><img style=' + qrCodeStyle + '; src=' + qrCodeApi + encodeURIComponent(groupLink) + '/></td>' + '</tr>';
            }

            $('#wandhi_table tbody').append(row);
          });
        }

        function getQueryString(name) {
          var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
          var reg_rewrite = new RegExp('(^|/)' + name + '/([^/]*)(/|$)', 'i');
          var r = window.location.search.substr(1).match(reg);
          var q = window.location.pathname.substr(1).match(reg_rewrite);

          if (r != null) {
            return unescape(r[2]);
          } else if (q != null) {
            return unescape(q[2]);
          } else {
            return '';
          }
        }
      }
    };

    var modules = [coupon];
    var prepare = {
      init: function init() {
        modules.forEach(function (module) {
          return module.init();
        });
      }
    };

    var prepares = [prepare$6, prepare$5, prepare$4, prepare$3, prepare$2, prepare$1, prepare];

    (function () {
      prepares.forEach(function (prepare) {
        return prepare.init();
      });
    })();

}());
